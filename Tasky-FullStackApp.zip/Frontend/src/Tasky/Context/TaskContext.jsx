import { createContext } from "react";

const taskContext = createContext();

export default taskContext;